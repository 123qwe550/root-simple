#!/bin/sh
# SD autorun /system/bin/goke_sd_boot.sh -> start.sh
# Never start capture before stock processes were disabled and 5 passes verified.
ROOT=/mnt/s0/goke
mkdir -p "$ROOT/logs"
echo "GOKE VIDEO AUTOSTART $(date)" >> "$ROOT/logs/goke_auto_boot.log"
sleep 15
/bin/sh "$ROOT/disable_stock.sh" >> "$ROOT/logs/goke_auto_boot.log" 2>&1
sleep 2
/bin/sh "$ROOT/goke_video_manager.sh" &
