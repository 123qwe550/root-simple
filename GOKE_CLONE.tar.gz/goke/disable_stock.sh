#!/bin/sh
# Stop only stock RTSP and recording; preserve sepcamera, network and guard.
LOG=/mnt/s0/goke/logs/disable_stock.log
mkdir -p /mnt/s0/goke/logs
{
  echo "=== STOP STOCK $(date) ==="
  echo '[1] Stop restart wrappers'
  for app in onvifd recorderd; do
    ps | awk -v app="$app" 'index($0,"/usr/bin/run_app.sh " app) && $1 ~ /^[0-9]+$/ {print $1}' | while read pid; do
      echo "wrapper $app PID=$pid"
      kill "$pid" 2>/dev/null
    done
  done
  sleep 2
  echo '[2] Stop RTSP and recording executables'
  for app in onvifd recorderd; do
    ps | awk -v app="$app" '$4 == "/usr/bin/" app && $1 ~ /^[0-9]+$/ {print $1}' | while read pid; do
      echo "service $app PID=$pid SIGTERM"
      kill "$pid" 2>/dev/null
    done
  done
  sleep 3
  echo '[3] Force-stop remaining RTSP/recording ONLY'
  for app in onvifd recorderd; do
    ps | awk -v app="$app" '$4 == "/usr/bin/" app && $1 ~ /^[0-9]+$/ {print $1}' | while read pid; do
      echo "service $app PID=$pid SIGKILL"
      kill -9 "$pid" 2>/dev/null
    done
  done
  sleep 2
  echo '[4] State'
  ps | awk '$4 == "/usr/bin/onvifd" || $4 == "/usr/bin/recorderd" || $4 == "/usr/bin/sepcamera" || $4 == "sepcamera" || index($0,"/usr/bin/run_app.sh onvifd") || index($0,"/usr/bin/run_app.sh recorderd") { print }'
  echo '=== END ==='
} >> "$LOG" 2>&1
 tail -25 "$LOG"
