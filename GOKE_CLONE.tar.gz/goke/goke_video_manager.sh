#!/bin/sh
# Goke SD boot manager: do not run custom video until 5-of-5 scan completed.
ROOT=/mnt/s0/goke
BIN=$ROOT/bin
DIR=/tmp/goke_video
LOG=$ROOT/logs/goke_auto_shm.log
SCANNER=$BIN/goke_shm_detect
WEB=$BIN/goke_mjpeg_web_v4
PORT=8080
mkdir -p "$DIR" "$ROOT/logs"
if [ ! -x "$WEB" ]; then echo "ERROR: V4 binary missing: $WEB" >> "$LOG"; exit 1; fi
exec >> "$LOG" 2>&1
echo "=== GOKE AUTO SHM manager $(date) ==="
# Prevent two managers if start script executed twice.
if [ -f "$DIR/manager.pid" ]; then
  old=`cat "$DIR/manager.pid" 2>/dev/null`
  if [ -n "$old" ] && kill -0 "$old" 2>/dev/null; then
    echo "Manager already running PID=$old";exit 0
  fi
fi
echo $$ > "$DIR/manager.pid"
trap 'rm -f "$DIR/READY" "$DIR/manager.pid"; exit 0' 1 2 15

scan_five(){
  rm -f "$DIR/READY" "$DIR/camera.env"
  : > "$DIR/scans.log"
  round=1
  while [ "$round" -le 5 ]; do
    echo "--- scan $round/5 $(date) ---"
    "$SCANNER" 160 > "$DIR/scan.tmp" 2>&1
    cat "$DIR/scan.tmp" >> "$DIR/scans.log"
    grep '^MAIN ' "$DIR/scan.tmp" | awk -v n="$round" '{print n,$2}' >> "$DIR/votes_main.tmp"
    grep '^SUB ' "$DIR/scan.tmp" | awk -v n="$round" '{print n,$2}' >> "$DIR/votes_sub.tmp"
    echo "scan $round:"
    grep -e '^MAIN ' -e '^SUB ' "$DIR/scan.tmp"
    round=$((round+1))
    sleep 2
  done
  # Choose most common ID, never arithmetic mean of SHM IDs.
  main_result=`awk '{count[$2]++} END {best="";v=0;ties=0;for(k in count) {if(count[k]>v){v=count[k];best=k;ties=1}else if(count[k]==v)ties++}if(best!="")print best,v,ties}' "$DIR/votes_main.tmp"`
  sub_result=`awk '{count[$2]++} END {best="";v=0;ties=0;for(k in count) {if(count[k]>v){v=count[k];best=k;ties=1}else if(count[k]==v)ties++}if(best!="")print best,v,ties}' "$DIR/votes_sub.tmp"`
  set -- $main_result
  main=${1:-};votes=${2:-0};ties=${3:-0}
  if [ "$votes" -lt 3 ] || [ "$ties" -ne 1 ]; then
    echo "NO CONSENSUS main=$main votes=$votes ties=$ties; will retry later"
    return 1
  fi
  set -- $sub_result
  sub=${1:-};sub_votes=${2:-0};sub_ties=${3:-0}
  if [ "$sub_votes" -lt 3 ] || [ "$sub_ties" -ne 1 ]; then sub=;fi
  # Recheck segment still exists, is 128K, and produces a valid JPEG.
  "$SCANNER" 200 > "$DIR/verify.tmp" 2>&1
  if ! grep -q "^MAIN $main " "$DIR/verify.tmp"; then
    echo "FINAL VERIFY FAIL for $main; retry";return 1
  fi
  mac=unknown
  if [ -r /sys/class/net/eth0/address ]; then mac=`cat /sys/class/net/eth0/address`;fi
  {
    echo "MAIN_SHMID=$main"
    echo "SUB_SHMID=$sub"
    echo "MAIN_VOTES=$votes"
    echo "SUB_VOTES=$sub_votes"
    echo "WIDTH=1280"
    echo "HEIGHT=720"
    echo "PORT=$PORT"
    echo "CAMERA_MAC=$mac"
    echo "VIDEO_PATH=/video1"
  } > "$DIR/camera.env.new"
  mv "$DIR/camera.env.new" "$DIR/camera.env"
  echo "SELECTED MAIN=$main ($votes/5), SUB=${sub:-none} ($sub_votes/5) MAC=$mac"
  return 0
}

start_web(){
  . "$DIR/camera.env"
  echo "Starting V4 MAIN_SHMID=$MAIN_SHMID"
  # Stop ONLY our older HTTP streamers, never sepcamera/network/guard.
  killall goke_mjpeg_web_v2 2>/dev/null
  killall goke_mjpeg_web_v3 2>/dev/null
  killall goke_mjpeg_web_v4 2>/dev/null
  killall goke_mjpeg_web_v5 2>/dev/null
  sleep 1
  "$WEB" "$PORT" "$MAIN_SHMID" 1280 720 >> "$ROOT/logs/mjpeg_v4_auto.log" 2>&1 &
  webpid=$!
  echo "$webpid" > "$DIR/web.pid"
  attempt=1
  while [ "$attempt" -le 15 ]; do
    if ! kill -0 "$webpid" 2>/dev/null;then echo 'V4 exited';return 1;fi
    status=`wget -q -T 2 -O - "http://127.0.0.1:$PORT/status" 2>/dev/null`
    f=`echo "$status" | sed -n 's/^frames=\([0-9]*\).*/\1/p'`
    if [ -n "$f" ] && [ "$f" -gt 0 ];then
      echo "READY $(date) frames=$f"
      echo "READY" > "$DIR/READY.new"
      mv "$DIR/READY.new" "$DIR/READY"
      return 0
    fi
    attempt=$((attempt+1))
    sleep 1
  done
  echo 'V4 startup timeout';return 1
}

# Verify requested encoder configuration, because AHD mode switching can rewrite
# /rom/config/video_channel_cfg.ini while the device is running.
CFG=/rom/config/video_channel_cfg.ini
RECOVERY_COOLDOWN=25
LAST_RESTART=0

fix_codec_if_needed(){
  [ -f "$CFG" ] || { echo "CODEC: missing $CFG"; return 1; }
  # Compare MAIN channel only. Other sections may deliberately use other values.
  section=`sed -n '/^\[master_channel_info0\]/,/^\[/p' "$CFG"`
  printf '%s\n' "$section" | grep -q '^codec_type=1$' &&
  printf '%s\n' "$section" | grep -q '^width=1280$' &&
  printf '%s\n' "$section" | grep -q '^height=720$' &&
  printf '%s\n' "$section" | grep -q '^frame_rate=25$' &&
  printf '%s\n' "$section" | grep -q '^bitrate=1200$' &&
  printf '%s\n' "$section" | grep -q '^rate_ctrl=0$' && return 0

  # Rate limit capture restarts during AHD signal flapping.
  now=`date +%s`
  case "$now" in ''|*[!0-9]*) now=0;; esac
  if [ "$LAST_RESTART" -gt 0 ] && [ "$now" -gt 0 ]; then
    diff=$((now-LAST_RESTART))
    if [ "$diff" -ge 0 ] && [ "$diff" -lt "$RECOVERY_COOLDOWN" ]; then
      echo "CODEC: configuration drift; waiting for cooldown (${diff}s)"
      return 1
    fi
  fi
  echo "CODEC: unexpected settings, restoring JPEG 1280x720 25fps $(date)"
  cp "$CFG" "$ROOT/logs/video_before_recovery.ini" 2>/dev/null
  # Match known keys across both channels, so JPEG substream is restored too.
  # Main-only keys are changed by matching their old, firmware-generated values.
  sed -i -e 's/^codec_type=2$/codec_type=1/g' \
         -e 's/^width=1920$/width=1280/g' \
         -e 's/^height=1080$/height=720/g' \
         -e 's/^frame_rate=30$/frame_rate=25/g' \
         -e 's/^bitrate=327$/bitrate=1200/g' \
         -e 's/^bitrate=288$/bitrate=1200/g' \
         -e 's/^rate_ctrl=1$/rate_ctrl=0/g' "$CFG" || return 1
  # Force normalized MAIN values even if AHD detector wrote other values.
  # Only edit lines between [master_channel_info0] and the next section.
  awk '
    /^\[master_channel_info0\]$/ {inside=1; print; next}
    /^\[/ {inside=0}
    inside && /^codec_type=/ {print "codec_type=1";next}
    inside && /^width=/ {print "width=1280";next}
    inside && /^height=/ {print "height=720";next}
    inside && /^frame_rate=/ {print "frame_rate=25";next}
    inside && /^bitrate=/ {print "bitrate=1200";next}
    inside && /^rate_ctrl=/ {print "rate_ctrl=0";next}
    {print}
  ' "$CFG" > "$DIR/video_channel_cfg.tmp" &&
  cat "$DIR/video_channel_cfg.tmp" > "$CFG" || return 1
  echo "CODEC: file repaired; restarting sepcamera and rediscovering SHM"
  LAST_RESTART=$now
  rm -f "$DIR/READY" "$DIR/camera.env"
  killall sepcamera 2>/dev/null
  sleep 8
  if ! pidof sepcamera >/dev/null 2>&1; then
    echo "CODEC: sepcamera did not restart automatically, launching directly"
    /usr/bin/sepcamera >> "$ROOT/logs/sepcamera_recovery.log" 2>&1 &
    sleep 5
  fi
  if pidof sepcamera >/dev/null 2>&1; then
    echo "CODEC: sepcamera running, scanning again"
  else
    echo "CODEC: ERROR sepcamera not running"
  fi
  return 2
}

# Initial existing stock-shutdown procedure is done by start.sh before manager.
while :; do
  fix_codec_if_needed
  : > "$DIR/votes_main.tmp"
  : > "$DIR/votes_sub.tmp"
  if scan_five && start_web; then
    bad=0
    while :; do
      sleep 5
      fix_codec_if_needed
      rc=$?
      if [ "$rc" -ne 0 ]; then echo "CODEC: changed or pending, rediscovering"; break; fi
      pid=`cat "$DIR/web.pid" 2>/dev/null`
      if [ -z "$pid" ] || ! kill -0 "$pid" 2>/dev/null;then
        echo 'V4 process exited';break
      fi
      status=`wget -q -T 2 -O - "http://127.0.0.1:$PORT/status" 2>/dev/null`
      age=`echo "$status" | sed -n 's/.*frame_age_ms=\([0-9]*\).*/\1/p'`
      if [ -z "$age" ] || [ "$age" -gt 12000 ]; then
        bad=$((bad+1));echo "V4 stale age=${age:-no_status} bad=$bad"
      else
        bad=0
      fi
      if [ "$bad" -ge 2 ];then echo 'V4 stale, rediscovery';break;fi
    done
  else
    echo 'Scan or V4 start failed, checking codec and retrying'
    fix_codec_if_needed
  fi
  rm -f "$DIR/READY"
  pid=`cat "$DIR/web.pid" 2>/dev/null`
  if [ -n "$pid" ];then kill "$pid" 2>/dev/null;fi
  sleep 3
  echo '=== NEW SCAN CYCLE ==='
done
